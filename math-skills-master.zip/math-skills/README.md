## Math_skills

 This program was mostly developed by user: mohani
 This program will calculate:

    Average
    Median
    Variance
    Standard Deviation


## Installation

Install math-skills with git

```bash
  git clone https://learn.reboot01.com/git/mohani/math-skills.git
  cd math-skills
```

 The program usage:
 go run math-skills.go data.txt

 data.txt should format should be like the following:
| 	         | 	
| 	:-----:	| 	
| 	123		| 
| 	123		| 
| 	123		| 
| 	123		| 
| 	123		| 

## Screenshots

![App Screenshot](https://snipboard.io/shz4ei.jpg)
![App Screenshot](https://snipboard.io/da2fEp.jpg)

## Authors

- [@mohani](https://learn.reboot01.com/git/mohani)

    






